-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: airlines
-- ------------------------------------------------------
-- Server version	8.2.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `distancegroups`
--

DROP TABLE IF EXISTS `distancegroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `distancegroups` (
  `%DistanceGroupID` int DEFAULT NULL,
  `DistanceInterval` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `distancegroups`
--

LOCK TABLES `distancegroups` WRITE;
/*!40000 ALTER TABLE `distancegroups` DISABLE KEYS */;
INSERT INTO `distancegroups` VALUES (1,'Less Than 500 Miles'),(2,'500-999 Miles'),(3,'1000-1499 Miles'),(4,'1500-1999 Miles'),(5,'2000-2499 Miles'),(6,'2500-2999 Miles'),(7,'3000-3499 Miles'),(8,'3500-3999 Miles'),(9,'4000-4499 Miles'),(10,'4500-4999 Miles'),(11,'5000-5499 Miles'),(12,'5500-5999 Miles'),(13,'6000-6499 Miles'),(14,'6500-6999 Miles'),(15,'7000-7499 Miles'),(16,'7500-7999 Miles'),(17,'8000-8499 Miles'),(18,'8500-8999 Miles'),(19,'9000-9499 Miles'),(20,'9500-9999 Miles'),(21,'10000-10499 Miles'),(22,'10500-10999 Miles'),(23,'11000-11499 Miles'),(24,'11500-11999 Miles'),(25,'12000 Miles and Greater');
/*!40000 ALTER TABLE `distancegroups` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-12-23 13:33:36
