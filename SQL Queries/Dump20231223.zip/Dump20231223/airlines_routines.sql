-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: airlines
-- ------------------------------------------------------
-- Server version	8.2.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Temporary view structure for view `orderdate`
--

DROP TABLE IF EXISTS `orderdate`;
/*!50001 DROP VIEW IF EXISTS `orderdate`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `orderdate` AS SELECT 
 1 AS `%AirlineID`,
 1 AS `OrderDate`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `kpi1`
--

DROP TABLE IF EXISTS `kpi1`;
/*!50001 DROP VIEW IF EXISTS `kpi1`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `kpi1` AS SELECT 
 1 AS `OrderDate`,
 1 AS `Years`,
 1 AS `Months`,
 1 AS `Days`,
 1 AS `Quarters`,
 1 AS `Year_Months`,
 1 AS `MonthName`,
 1 AS `weekday_number`,
 1 AS `weekday_name`,
 1 AS `financial_month`,
 1 AS `financial_quarter`,
 1 AS `WeekEnd_Weekday`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `orderdatename`
--

DROP TABLE IF EXISTS `orderdatename`;
/*!50001 DROP VIEW IF EXISTS `orderdatename`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `orderdatename` AS SELECT 
 1 AS `%AirlineID`,
 1 AS `OrderDate`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `orderdate`
--

/*!50001 DROP VIEW IF EXISTS `orderdate`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `orderdate` AS select `maindata_final1`.`%AirlineID` AS `%AirlineID`,str_to_date(concat(`maindata_final1`.`Year`,'-',`maindata_final1`.`Month`,'-',`maindata_final1`.`Day`),'%Y-%m-%d') AS `OrderDate` from `maindata_final1` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `kpi1`
--

/*!50001 DROP VIEW IF EXISTS `kpi1`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `kpi1` AS select str_to_date(concat(`maindata_final`.`Year`,'-',`maindata_final`.`Month`,'-',`maindata_final`.`Day`),'%Y-%m-%d') AS `OrderDate`,year(`maindata_final`.`OrderDate`) AS `Years`,month(`maindata_final`.`OrderDate`) AS `Months`,weekday(`maindata_final`.`OrderDate`) AS `Days`,concat('Q-',quarter(`maindata_final`.`OrderDate`)) AS `Quarters`,date_format(`maindata_final`.`OrderDate`,'%Y-%M') AS `Year_Months`,monthname(`maindata_final`.`OrderDate`) AS `MonthName`,dayofweek(`maindata_final`.`OrderDate`) AS `weekday_number`,dayname(`maindata_final`.`OrderDate`) AS `weekday_name`,month((`maindata_final`.`OrderDate` + interval -(3) month)) AS `financial_month`,concat('Q-',quarter((`maindata_final`.`OrderDate` + interval -(3) month))) AS `financial_quarter`,if(((dayname(`maindata_final`.`OrderDate`) = 'Saturday') or (dayname(`maindata_final`.`OrderDate`) = 'Sunday')),'WeekEnd','WeekDay') AS `WeekEnd_Weekday` from `maindata_final` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `orderdatename`
--

/*!50001 DROP VIEW IF EXISTS `orderdatename`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `orderdatename` AS select `maindata_final1`.`%AirlineID` AS `%AirlineID`,str_to_date(concat(`maindata_final1`.`Year`,'-',`maindata_final1`.`Month`,'-',`maindata_final1`.`Day`),'%Y-%m-%d') AS `OrderDate` from `maindata_final1` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-12-23 13:33:38
